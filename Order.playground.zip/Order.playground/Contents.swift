import UIKit

let FinalEquation = {
    (no1:Int , no2: Int) -> Int in
return no1 + no2
}
let Numbers = FinalEquation(432,113)
print(Numbers)
